package com.cg.gmail;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class YoutubeAutomation
{
    public static void main( String[] args )
    {
    		System.setProperty("webdriver.chrome.driver","C://chromedriver/chromedriver.exe");
    		WebDriver driver = new  ChromeDriver();
    		driver.manage().window().maximize();
    		driver.get("http://newtours.demoaut.com/");
    		driver.findElement(By.xpath("//a[contains(text(),'REGISTER')]")).click();
    		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("Ganesh");
    		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("Obilisetti");
    		driver.findElement(By.xpath("//input[@name='phone']")).sendKeys("8500451143");
    		driver.findElement(By.xpath("//input[@id='userName']")).sendKeys("sriramganesh710@gmail.com");
    		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Ganesh");
    		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Ganesh143");
    		driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys("Ganesh143");
    		driver.findElement(By.xpath("//input[@name='register']")).click();
    		
    }
}
