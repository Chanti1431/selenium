package com.cg.IcompassAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class App 
{
    	public static void main(String[] args) {
    		//Step1: Setup the driver settings
    		System.setProperty("webdriver.chrome.driver","C://chromedriver/chromedriver.exe");
    		//Step2:Create Webdriver object
    		WebDriver driver = new  ChromeDriver();
    		//Step3:Open url
    		driver.get("https://icompassweb.fs.capgemini.com/iCompass/#/login");
    		driver.findElement(By.xpath("//input[@id='userName']")).sendKeys("186110");
    		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Pretty*lady");
    		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
    		
    }
}
