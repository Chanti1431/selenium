package firstselenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WikiopediaTest {
	public static void main(String[] args) {
		//Step1: Setup the driver settings
		System.setProperty("webdriver.chrome.driver","C://chromedriver/chromedriver.exe");
		//Step2:Create Webdriver object
		WebDriver driver = new  ChromeDriver();
		driver.manage().window().maximize();
		//Step3:Open url
		driver.get("https://www.wikipedia.org/");
		driver.findElement(By.xpath("//input[@id='searchInput']")).sendKeys("Cricket");
		driver.findElement(By.xpath("//i[@class='sprite svg-search-icon']")).click();
		driver.close();
	}
}
